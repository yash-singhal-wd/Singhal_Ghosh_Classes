#include <bits/stdc++.h>

using namespace std;

//use recursion

void print_1_to_n(int n){
    // add your code here
}

void print_n_to_1(int n){
    // add your code here
}

int main(){
    int n;
    cin >> n;
    print_1_to_n(n);
    cout << endl;
    print_n_to_1(n);
    return 1;
}